SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'budget',
  `status` tinyint(4) DEFAULT '1',
  `account_id` bigint(20) UNSIGNED DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `accounts` (`id`, `name`, `type`, `status`, `account_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'test', 'budget', 1, NULL, '2022-04-30 17:56:38', '2022-04-30 17:56:38', NULL);

CREATE TABLE `action_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_id` bigint(20) UNSIGNED NOT NULL,
  `target_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED DEFAULT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `exception` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `original` mediumtext COLLATE utf8mb4_unicode_ci,
  `changes` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `action_events` (`id`, `batch_id`, `user_id`, `name`, `actionable_type`, `actionable_id`, `target_type`, `target_id`, `model_type`, `model_id`, `fields`, `status`, `exception`, `created_at`, `updated_at`, `original`, `changes`) VALUES
(1, '961fa9f0-b862-4ccb-8094-bc3c020a89bc', 1, 'Create', 'App\\Models\\Info\\Project\\Project', 1, 'App\\Models\\Info\\Project\\Project', 1, 'App\\Models\\Info\\Project\\Project', 1, '', 'finished', '', '2022-04-22 11:36:32', '2022-04-22 11:36:32', NULL, '{\"name\":\"P1\",\"cost\":100000,\"project_status_id\":1,\"status\":1,\"updated_at\":\"2022-04-22T11:36:32.000000Z\",\"created_at\":\"2022-04-22T11:36:32.000000Z\",\"id\":1}'),
(2, '961fa9f8-8e88-486a-a73e-033a9650be29', 1, 'Create', 'App\\Models\\Sheet\\Credit', 1, 'App\\Models\\Sheet\\Credit', 1, 'App\\Models\\Sheet\\Credit', 1, '', 'finished', '', '2022-04-22 11:36:37', '2022-04-22 11:36:37', NULL, '{\"date\":\"2022-03-31T00:00:00.000000Z\",\"amount\":100,\"vat_included\":false,\"project_id\":1,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-22T11:36:37.000000Z\",\"created_at\":\"2022-04-22T11:36:37.000000Z\",\"id\":1}'),
(3, '961faa16-d0df-40cc-958f-edb9e5f563ad', 1, 'Create', 'App\\Models\\Sheet\\Credit', 2, 'App\\Models\\Sheet\\Credit', 2, 'App\\Models\\Sheet\\Credit', 2, '', 'finished', '', '2022-04-22 11:36:57', '2022-04-22 11:36:57', NULL, '{\"date\":\"2022-04-01T00:00:00.000000Z\",\"amount\":500,\"vat_included\":false,\"project_id\":1,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-22T11:36:57.000000Z\",\"created_at\":\"2022-04-22T11:36:57.000000Z\",\"id\":2}'),
(4, '961faa33-f077-4ddd-975c-85f33f52802f', 1, 'Create', 'App\\Models\\Info\\Project\\Project', 2, 'App\\Models\\Info\\Project\\Project', 2, 'App\\Models\\Info\\Project\\Project', 2, '', 'finished', '', '2022-04-22 11:37:16', '2022-04-22 11:37:16', NULL, '{\"name\":\"P2\",\"cost\":500000,\"project_status_id\":1,\"status\":1,\"updated_at\":\"2022-04-22T11:37:16.000000Z\",\"created_at\":\"2022-04-22T11:37:16.000000Z\",\"id\":2}'),
(5, '961faa3c-70bb-4601-8b2c-37ce436cd4d6', 1, 'Create', 'App\\Models\\Sheet\\Credit', 3, 'App\\Models\\Sheet\\Credit', 3, 'App\\Models\\Sheet\\Credit', 3, '', 'finished', '', '2022-04-22 11:37:22', '2022-04-22 11:37:22', NULL, '{\"date\":\"2022-04-01T00:00:00.000000Z\",\"amount\":12,\"vat_included\":false,\"project_id\":2,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-22T11:37:22.000000Z\",\"created_at\":\"2022-04-22T11:37:22.000000Z\",\"id\":3}'),
(6, '961faa55-d695-4929-a511-d2353cf26baf', 1, 'Create', 'App\\Models\\Sheet\\Credit', 4, 'App\\Models\\Sheet\\Credit', 4, 'App\\Models\\Sheet\\Credit', 4, '', 'finished', '', '2022-04-22 11:37:39', '2022-04-22 11:37:39', NULL, '{\"date\":\"2022-05-03T00:00:00.000000Z\",\"amount\":100,\"vat_included\":false,\"project_id\":2,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-22T11:37:39.000000Z\",\"created_at\":\"2022-04-22T11:37:39.000000Z\",\"id\":4}'),
(7, '961faa72-397a-4e62-9af2-6c70b6dbe619', 1, 'Create', 'App\\Models\\Sheet\\Expense', 1, 'App\\Models\\Sheet\\Expense', 1, 'App\\Models\\Sheet\\Expense', 1, '', 'finished', '', '2022-04-22 11:37:57', '2022-04-22 11:37:57', NULL, '{\"date\":\"2022-03-31T00:00:00.000000Z\",\"amount\":100,\"vat_included\":false,\"project_id\":1,\"entry_category_id\":7,\"remarks\":null,\"updated_at\":\"2022-04-22T11:37:57.000000Z\",\"created_at\":\"2022-04-22T11:37:57.000000Z\",\"id\":1}'),
(8, '961faa84-cf87-42b1-9af0-ce562edf015a', 1, 'Create', 'App\\Models\\Sheet\\Expense', 2, 'App\\Models\\Sheet\\Expense', 2, 'App\\Models\\Sheet\\Expense', 2, '', 'finished', '', '2022-04-22 11:38:09', '2022-04-22 11:38:09', NULL, '{\"date\":\"2022-03-31T00:00:00.000000Z\",\"amount\":50,\"vat_included\":false,\"project_id\":2,\"entry_category_id\":12,\"remarks\":null,\"updated_at\":\"2022-04-22T11:38:09.000000Z\",\"created_at\":\"2022-04-22T11:38:09.000000Z\",\"id\":2}'),
(9, '961faa9f-b941-4d70-a893-79490b838b23', 1, 'Create', 'App\\Models\\Sheet\\Expense', 3, 'App\\Models\\Sheet\\Expense', 3, 'App\\Models\\Sheet\\Expense', 3, '', 'finished', '', '2022-04-22 11:38:27', '2022-04-22 11:38:27', NULL, '{\"date\":\"2022-04-02T00:00:00.000000Z\",\"amount\":80,\"vat_included\":false,\"project_id\":1,\"entry_category_id\":12,\"remarks\":null,\"updated_at\":\"2022-04-22T11:38:27.000000Z\",\"created_at\":\"2022-04-22T11:38:27.000000Z\",\"id\":3}'),
(10, '961faaba-602c-4119-93c4-ac0fe137b01b', 1, 'Create', 'App\\Models\\Sheet\\Expense', 4, 'App\\Models\\Sheet\\Expense', 4, 'App\\Models\\Sheet\\Expense', 4, '', 'finished', '', '2022-04-22 11:38:44', '2022-04-22 11:38:44', NULL, '{\"date\":\"2022-05-04T00:00:00.000000Z\",\"amount\":100,\"vat_included\":false,\"project_id\":2,\"entry_category_id\":7,\"remarks\":null,\"updated_at\":\"2022-04-22T11:38:44.000000Z\",\"created_at\":\"2022-04-22T11:38:44.000000Z\",\"id\":4}'),
(11, '961fab29-cd2b-4562-87d8-6d51d6968b70', 1, 'Create', 'App\\Models\\Sheet\\Expense', 5, 'App\\Models\\Sheet\\Expense', 5, 'App\\Models\\Sheet\\Expense', 5, '', 'finished', '', '2022-04-22 11:39:57', '2022-04-22 11:39:57', NULL, '{\"date\":\"2022-05-31T00:00:00.000000Z\",\"amount\":500,\"vat_included\":false,\"project_id\":1,\"entry_category_id\":6,\"remarks\":null,\"updated_at\":\"2022-04-22T11:39:57.000000Z\",\"created_at\":\"2022-04-22T11:39:57.000000Z\",\"id\":5}'),
(12, '961fab46-0563-47a0-bd13-47b0b98e4e17', 1, 'Create', 'App\\Models\\Sheet\\Expense', 6, 'App\\Models\\Sheet\\Expense', 6, 'App\\Models\\Sheet\\Expense', 6, '', 'finished', '', '2022-04-22 11:40:16', '2022-04-22 11:40:16', NULL, '{\"date\":\"2022-06-08T00:00:00.000000Z\",\"amount\":550,\"vat_included\":false,\"project_id\":2,\"entry_category_id\":13,\"remarks\":null,\"updated_at\":\"2022-04-22T11:40:16.000000Z\",\"created_at\":\"2022-04-22T11:40:16.000000Z\",\"id\":6}'),
(13, '961fcd70-a541-4117-b8b8-acc35e732eec', 1, 'Create', 'App\\Models\\Sheet\\Credit', 5, 'App\\Models\\Sheet\\Credit', 5, 'App\\Models\\Sheet\\Credit', 5, '', 'finished', '', '2022-04-22 13:15:48', '2022-04-22 13:15:48', NULL, '{\"date\":\"2022-04-11T00:00:00.000000Z\",\"amount\":23,\"vat_included\":false,\"project_id\":2,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-22T13:15:48.000000Z\",\"created_at\":\"2022-04-22T13:15:48.000000Z\",\"id\":5}'),
(14, '962054ef-11db-4065-8af3-48d7813384f1', 1, 'Create', 'App\\Models\\Sheet\\Credit', 6, 'App\\Models\\Sheet\\Credit', 6, 'App\\Models\\Sheet\\Credit', 6, '', 'finished', '', '2022-04-22 19:34:40', '2022-04-22 19:34:40', NULL, '{\"date\":\"2022-09-13T00:00:00.000000Z\",\"amount\":20,\"vat_included\":false,\"project_id\":1,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-22T19:34:40.000000Z\",\"created_at\":\"2022-04-22T19:34:40.000000Z\",\"id\":6}'),
(15, '9620550b-4c4b-4e8d-b261-9de0095ba782', 1, 'Create', 'App\\Models\\Sheet\\Expense', 7, 'App\\Models\\Sheet\\Expense', 7, 'App\\Models\\Sheet\\Expense', 7, '', 'finished', '', '2022-04-22 19:34:59', '2022-04-22 19:34:59', NULL, '{\"date\":\"2022-09-13T00:00:00.000000Z\",\"amount\":10,\"vat_included\":false,\"project_id\":1,\"entry_category_id\":7,\"remarks\":null,\"updated_at\":\"2022-04-22T19:34:59.000000Z\",\"created_at\":\"2022-04-22T19:34:59.000000Z\",\"id\":7}'),
(16, '962e0d79-7425-4bf5-8343-babd1f08876d', 1, 'Create', 'App\\Models\\Sheet\\Credit', 7, 'App\\Models\\Sheet\\Credit', 7, 'App\\Models\\Sheet\\Credit', 7, '', 'finished', '', '2022-04-29 15:16:27', '2022-04-29 15:16:27', NULL, '{\"date\":\"2022-01-04T00:00:00.000000Z\",\"amount\":34,\"vat_included\":false,\"project_id\":1,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-29T15:16:27.000000Z\",\"created_at\":\"2022-04-29T15:16:27.000000Z\",\"id\":7}'),
(17, '962fee8c-ca77-43c4-a838-dd626362231f', 1, 'Create', 'App\\Models\\Info\\Project\\Project', 3, 'App\\Models\\Info\\Project\\Project', 3, 'App\\Models\\Info\\Project\\Project', 3, '', 'finished', '', '2022-04-30 13:41:38', '2022-04-30 13:41:38', NULL, '{\"name\":\"P3\",\"cost\":10,\"project_status_id\":1,\"status\":1,\"updated_at\":\"2022-04-30T13:41:38.000000Z\",\"created_at\":\"2022-04-30T13:41:38.000000Z\",\"id\":3}'),
(18, '9630268f-606f-43dd-8250-f0204a4db97f', 1, 'Create', 'App\\Models\\Sheet\\Expense', 8, 'App\\Models\\Sheet\\Expense', 8, 'App\\Models\\Sheet\\Expense', 8, '', 'finished', '', '2022-04-30 16:18:15', '2022-04-30 16:18:15', NULL, '{\"date\":\"2022-03-29T00:00:00.000000Z\",\"amount\":10,\"vat_included\":false,\"project_id\":3,\"entry_category_id\":10,\"remarks\":null,\"updated_at\":\"2022-04-30T16:18:15.000000Z\",\"created_at\":\"2022-04-30T16:18:15.000000Z\",\"id\":8}'),
(19, '963026bc-35f5-4609-a701-c97753872385', 1, 'Update', 'App\\Models\\Sheet\\Expense', 8, 'App\\Models\\Sheet\\Expense', 8, 'App\\Models\\Sheet\\Expense', 8, '', 'finished', '', '2022-04-30 16:18:44', '2022-04-30 16:18:44', '{\"project_id\":3}', '{\"project_id\":2}'),
(20, '96302754-021f-45fd-bb01-968bb29039cd', 1, 'Update', 'App\\Models\\Sheet\\Expense', 8, 'App\\Models\\Sheet\\Expense', 8, 'App\\Models\\Sheet\\Expense', 8, '', 'finished', '', '2022-04-30 16:20:24', '2022-04-30 16:20:24', '{\"project_id\":2}', '{\"project_id\":3}'),
(21, '96302770-6488-4a0e-83f6-18e6c858ee25', 1, 'Create', 'App\\Models\\Sheet\\Credit', 8, 'App\\Models\\Sheet\\Credit', 8, 'App\\Models\\Sheet\\Credit', 8, '', 'finished', '', '2022-04-30 16:20:42', '2022-04-30 16:20:42', NULL, '{\"date\":\"2022-07-18T00:00:00.000000Z\",\"amount\":1000,\"vat_included\":true,\"project_id\":3,\"credit_category_id\":1,\"remarks\":null,\"updated_at\":\"2022-04-30T16:20:42.000000Z\",\"created_at\":\"2022-04-30T16:20:42.000000Z\",\"id\":8}'),
(22, '9630491f-3576-4d30-a2fc-10a17723a08f', 1, 'Detach', 'App\\Models\\Settings\\Role', 1, 'App\\Models\\Settings\\Permission', 1, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:54:53', '2022-04-30 17:54:53', NULL, NULL),
(23, '9630491f-39d8-4382-b694-474d49d9a4cd', 1, 'Detach', 'App\\Models\\Settings\\Role', 1, 'App\\Models\\Settings\\Permission', 2, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:54:53', '2022-04-30 17:54:53', NULL, NULL),
(24, '9630491f-3c42-497f-9504-6c2fcec7084e', 1, 'Detach', 'App\\Models\\Settings\\Role', 1, 'App\\Models\\Settings\\Permission', 3, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:54:53', '2022-04-30 17:54:53', NULL, NULL),
(25, '9630491f-3e60-4675-8ed5-f96815214480', 1, 'Detach', 'App\\Models\\Settings\\Role', 1, 'App\\Models\\Settings\\Permission', 4, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:54:53', '2022-04-30 17:54:53', NULL, NULL),
(26, '9630491f-4051-4dea-bdb4-e562a4b62d70', 1, 'Detach', 'App\\Models\\Settings\\Role', 1, 'App\\Models\\Settings\\Permission', 5, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:54:53', '2022-04-30 17:54:53', NULL, NULL),
(27, '9630491f-4261-45ef-9a8e-719175a05a9f', 1, 'Detach', 'App\\Models\\Settings\\Role', 1, 'App\\Models\\Settings\\Permission', 6, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:54:53', '2022-04-30 17:54:53', NULL, NULL),
(28, '9630491f-444d-4bed-a499-c0512eaf7057', 1, 'Detach', 'App\\Models\\Settings\\Role', 1, 'App\\Models\\Settings\\Permission', 7, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:54:53', '2022-04-30 17:54:53', NULL, NULL),
(29, '963049bf-6d6e-4a6d-81cf-b1422eb07f93', 1, 'Create', 'App\\Models\\Chart\\Account', 1, 'App\\Models\\Chart\\Account', 1, 'App\\Models\\Chart\\Account', 1, '', 'finished', '', '2022-04-30 17:56:38', '2022-04-30 17:56:38', NULL, '{\"name\":\"test\",\"type\":\"budget\",\"account_id\":null,\"status\":1,\"updated_at\":\"2022-04-30T17:56:38.000000Z\",\"created_at\":\"2022-04-30T17:56:38.000000Z\",\"id\":1}'),
(30, '96304a9c-78b9-4795-b66e-e8ae7b95430a', 1, 'Create', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Role', 2, '', 'finished', '', '2022-04-30 17:59:03', '2022-04-30 17:59:03', NULL, '{\"name\":\"user\",\"guard_name\":\"web\",\"updated_at\":\"2022-04-30T17:59:03.000000Z\",\"created_at\":\"2022-04-30T17:59:03.000000Z\",\"id\":2}'),
(31, '96304aac-5fd8-4238-975d-7061f1755a8d', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 10, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:14', '2022-04-30 17:59:14', NULL, '{\"role_id\":\"2\",\"permission_id\":\"10\"}'),
(32, '96304ab3-6287-4c3d-a36e-4b507ebc6c3f', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 12, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:18', '2022-04-30 17:59:18', NULL, '{\"role_id\":\"2\",\"permission_id\":\"12\"}'),
(33, '96304ab7-c57f-4be2-bb8a-9e792ebd5ab2', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 11, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:21', '2022-04-30 17:59:21', NULL, '{\"role_id\":\"2\",\"permission_id\":\"11\"}'),
(34, '96304abd-72f8-4af1-9ee8-8ad0fb7b334c', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 14, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:25', '2022-04-30 17:59:25', NULL, '{\"role_id\":\"2\",\"permission_id\":\"14\"}'),
(35, '96304ac1-1d78-4dca-af8d-e84f7e608a5d', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 13, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:27', '2022-04-30 17:59:27', NULL, '{\"role_id\":\"2\",\"permission_id\":\"13\"}'),
(36, '96304ac4-cf0a-4b83-ba75-34666fd919d9', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 9, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:30', '2022-04-30 17:59:30', NULL, '{\"role_id\":\"2\",\"permission_id\":\"9\"}'),
(37, '96304ac8-5937-4fa3-91ba-0d3edbbaef7a', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 8, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:32', '2022-04-30 17:59:32', NULL, '{\"role_id\":\"2\",\"permission_id\":\"8\"}'),
(38, '96304acb-e7f3-4076-b3c9-0adf4abaed87', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 59, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:34', '2022-04-30 17:59:34', NULL, '{\"role_id\":\"2\",\"permission_id\":\"59\"}'),
(39, '96304acf-d1b1-4f56-a7b8-824603be5d31', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 61, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:37', '2022-04-30 17:59:37', NULL, '{\"role_id\":\"2\",\"permission_id\":\"61\"}'),
(40, '96304ad3-99d9-4491-a253-8703c72ed91f', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 60, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:39', '2022-04-30 17:59:39', NULL, '{\"role_id\":\"2\",\"permission_id\":\"60\"}'),
(41, '96304ad6-b3ee-41ff-ba87-d0cdc8136a58', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 63, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:41', '2022-04-30 17:59:41', NULL, '{\"role_id\":\"2\",\"permission_id\":\"63\"}'),
(42, '96304ada-1ede-4506-98a8-80ed7aec854e', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 62, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:44', '2022-04-30 17:59:44', NULL, '{\"role_id\":\"2\",\"permission_id\":\"62\"}'),
(43, '96304add-7d0a-425c-ac7b-cef14bbf2bbb', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 58, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:46', '2022-04-30 17:59:46', NULL, '{\"role_id\":\"2\",\"permission_id\":\"58\"}'),
(44, '96304ae0-a2a3-4fcd-814f-497f0d3a4a89', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 57, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:48', '2022-04-30 17:59:48', NULL, '{\"role_id\":\"2\",\"permission_id\":\"57\"}'),
(45, '96304ae3-8ce3-40e0-b6ee-784cc00d9890', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 52, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:50', '2022-04-30 17:59:50', NULL, '{\"role_id\":\"2\",\"permission_id\":\"52\"}'),
(46, '96304ae6-e48f-4f98-90e2-c67bea91d651', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 54, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:52', '2022-04-30 17:59:52', NULL, '{\"role_id\":\"2\",\"permission_id\":\"54\"}'),
(47, '96304aea-c4e5-4734-9485-7d015028015e', 1, 'Attach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 53, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 17:59:54', '2022-04-30 17:59:54', NULL, '{\"role_id\":\"2\",\"permission_id\":\"53\"}'),
(48, '96304b1d-9234-407c-8b67-7f94c3232b5f', 1, 'Create', 'App\\Models\\Info\\User', 2, 'App\\Models\\Info\\User', 2, 'App\\Models\\Info\\User', 2, '', 'finished', '', '2022-04-30 18:00:28', '2022-04-30 18:00:28', NULL, '{\"locale\":\"ar\",\"name\":\"user\",\"email\":\"user@user.com\",\"updated_at\":\"2022-04-30T18:00:28.000000Z\",\"created_at\":\"2022-04-30T18:00:28.000000Z\",\"id\":2}'),
(49, '96304b2b-ba9e-4f1c-9e6b-455b37447a25', 1, 'Attach', 'App\\Models\\Info\\User', 2, 'App\\Models\\Settings\\Role', 2, 'Illuminate\\Database\\Eloquent\\Relations\\MorphPivot', NULL, '', 'finished', '', '2022-04-30 18:00:37', '2022-04-30 18:00:37', NULL, '{\"model_id\":\"2\",\"role_id\":\"2\",\"model_type\":\"App\\\\Models\\\\Info\\\\User\"}'),
(50, '96304b4d-7683-4ddf-8fbe-4f9eda59ff96', 1, 'Update', 'App\\Models\\Info\\User', 2, 'App\\Models\\Info\\User', 2, 'App\\Models\\Info\\User', 2, '', 'finished', '', '2022-04-30 18:00:59', '2022-04-30 18:00:59', '{\"password\":\"$2y$10$aHyydVHTLNWacX9.Q5ZbxO7aPj3UAdPQMgrGCp5cD8PuYZuWO9OdC\"}', '{\"password\":\"$2y$10$4frw\\/LR4iJcJg2BEps7ECupjhqtS4Kv.N9QdHHCeBSH2slwT\\/dQBa\"}'),
(51, '96304bf2-3d82-4794-995b-3da265f6b40a', 1, 'Update', 'App\\Models\\Info\\User', 2, 'App\\Models\\Info\\User', 2, 'App\\Models\\Info\\User', 2, '', 'finished', '', '2022-04-30 18:02:47', '2022-04-30 18:02:47', '{\"password\":\"$2y$10$4frw\\/LR4iJcJg2BEps7ECupjhqtS4Kv.N9QdHHCeBSH2slwT\\/dQBa\"}', '{\"password\":\"$2y$10$m6E1SnZlM2txm.WcSc06qOCaPFcDya2\\/lsypjPCV64LtZ6Q7UCquC\"}'),
(52, '96304d16-1956-4fea-888e-7758384c1284', 2, 'Create', 'App\\Models\\Info\\Client', 1, 'App\\Models\\Info\\Client', 1, 'App\\Models\\Info\\Client', 1, '', 'finished', '', '2022-04-30 18:05:58', '2022-04-30 18:05:58', NULL, '{\"name\":{\"en\":\"Client\",\"ar\":\"\\u0639\\u0645\\u064a\\u0644\"},\"type\":\"cash\",\"status\":1,\"updated_at\":\"2022-04-30T18:05:58.000000Z\",\"created_at\":\"2022-04-30T18:05:58.000000Z\",\"id\":1}'),
(53, '96304d54-e1ce-4747-b110-2522c468e57a', 2, 'Detach', 'App\\Models\\Settings\\Role', 2, 'App\\Models\\Settings\\Permission', 10, 'Illuminate\\Database\\Eloquent\\Relations\\Pivot', NULL, '', 'finished', '', '2022-04-30 18:06:40', '2022-04-30 18:06:40', NULL, NULL);

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `clients` (`id`, `name`, `type`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '{\"en\":\"Client\",\"ar\":\"\\u0639\\u0645\\u064a\\u0644\"}', 'cash', 1, '2022-04-30 18:05:58', '2022-04-30 18:05:58', NULL);

CREATE TABLE `credits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `project_id` bigint(20) UNSIGNED DEFAULT NULL,
  `credit_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` double DEFAULT '0',
  `vat_included` tinyint(1) DEFAULT '0',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `credits` (`id`, `date`, `project_id`, `credit_category_id`, `amount`, `vat_included`, `remarks`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '2022-03-31 21:00:00', 1, 1, 100, 0, NULL, '2022-04-22 11:36:37', '2022-04-22 11:36:37', NULL),
(2, '2022-04-01 21:00:00', 1, 1, 500, 0, NULL, '2022-04-22 11:36:57', '2022-04-22 11:36:57', NULL),
(3, '2022-04-01 21:00:00', 2, 1, 12, 0, NULL, '2022-04-22 11:37:22', '2022-04-22 11:37:22', NULL),
(4, '2022-05-03 21:00:00', 2, 1, 100, 0, NULL, '2022-04-22 11:37:39', '2022-04-22 11:37:39', NULL),
(5, '2022-04-11 21:00:00', 2, 1, 23, 0, NULL, '2022-04-22 13:15:48', '2022-04-22 13:15:48', NULL),
(6, '2022-09-13 21:00:00', 1, 1, 20, 0, NULL, '2022-04-22 19:34:40', '2022-04-22 19:34:40', NULL),
(7, '2022-01-04 21:00:00', 1, 1, 34, 0, NULL, '2022-04-29 15:16:27', '2022-04-29 15:16:27', NULL),
(8, '2022-07-18 21:00:00', 3, 1, 1000, 1, NULL, '2022-04-30 16:20:42', '2022-04-30 16:20:42', NULL);

CREATE TABLE `credit_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `credit_categories` (`id`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Cash', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL);

CREATE TABLE `entry_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `entry_categories` (`id`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Rent / Mortgage', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(2, 'Materials / Maintenance', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(3, 'Grocery / Food Items', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(4, 'Petrol / Transportation', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(5, 'Utilities', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(6, 'Cash to Imad', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(7, 'Cash to / Employee / Site / Labour', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(8, 'Stationary', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(9, 'Government Charges and Fees', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(10, 'Store', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(11, 'Miscellaneous', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(12, 'Salary', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(13, 'Overtime', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(14, 'Insurance', 1, '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL);

CREATE TABLE `expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `project_id` bigint(20) UNSIGNED DEFAULT NULL,
  `entry_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` double DEFAULT '0',
  `vat_included` tinyint(1) DEFAULT '0',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `expenses` (`id`, `date`, `project_id`, `entry_category_id`, `amount`, `vat_included`, `remarks`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '2022-03-31 21:00:00', 1, 7, 100, 0, NULL, '2022-04-22 11:37:57', '2022-04-22 11:37:57', NULL),
(2, '2022-03-31 21:00:00', 2, 12, 50, 0, NULL, '2022-04-22 11:38:09', '2022-04-22 11:38:09', NULL),
(3, '2022-04-02 21:00:00', 1, 12, 80, 0, NULL, '2022-04-22 11:38:27', '2022-04-22 11:38:27', NULL),
(4, '2022-05-04 21:00:00', 2, 7, 100, 0, NULL, '2022-04-22 11:38:44', '2022-04-22 11:38:44', NULL),
(5, '2022-05-31 21:00:00', 1, 6, 500, 0, NULL, '2022-04-22 11:39:57', '2022-04-22 11:39:57', NULL),
(6, '2022-06-08 21:00:00', 2, 13, 550, 0, NULL, '2022-04-22 11:40:16', '2022-04-22 11:40:16', NULL),
(7, '2022-09-13 21:00:00', 1, 7, 10, 0, NULL, '2022-04-22 19:34:59', '2022-04-22 19:34:59', NULL),
(8, '2022-03-29 21:00:00', 3, 10, 10, 0, NULL, '2022-04-30 16:18:15', '2022-04-30 16:20:24', NULL);

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `language_lines` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2018_01_01_000000_create_action_events_table', 1),
(3, '2019_05_10_000000_add_fields_to_action_events_table', 1),
(4, '2019_11_08_000000_create_menus_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2022_02_14_065824_create_failed_jobs_table', 1),
(7, '2022_02_14_065824_create_language_lines_table', 1),
(8, '2022_02_14_065824_create_media_table', 1),
(9, '2022_02_14_065824_create_model_has_permissions_table', 1),
(10, '2022_02_14_065824_create_model_has_roles_table', 1),
(11, '2022_02_14_065824_create_nova_froala_attachments_table', 1),
(12, '2022_02_14_065824_create_nova_pending_froala_attachments_table', 1),
(13, '2022_02_14_065824_create_nova_pending_trix_attachments_table', 1),
(14, '2022_02_14_065824_create_nova_trix_attachments_table', 1),
(15, '2022_02_14_065824_create_password_resets_table', 1),
(16, '2022_02_14_065824_create_permissions_table', 1),
(17, '2022_02_14_065824_create_role_has_permissions_table', 1),
(18, '2022_02_14_065824_create_roles_table', 1),
(19, '2022_02_14_065824_create_settings_table', 1),
(20, '2022_02_14_065825_add_foreign_keys_to_model_has_permissions_table', 1),
(21, '2022_02_14_065825_add_foreign_keys_to_model_has_roles_table', 1),
(22, '2022_02_14_065825_add_foreign_keys_to_role_has_permissions_table', 1),
(23, '2022_03_10_092534_create_accounts_table', 1),
(24, '2022_03_19_071745_create_clients_table', 1),
(25, '2022_03_19_081745_create_entry_categories_table', 1),
(26, '2022_03_19_091745_create_projects_table', 1),
(27, '2022_03_20_001745_create_project_statuses_table', 1),
(28, '2022_03_20_091745_create_expenses_table', 1),
(29, '2022_03_20_204749_add_status_to_projects_table', 1),
(30, '2022_04_05_191014_add_cost_column_to_projects_table', 1),
(31, '2022_04_22_081745_create_credit_categories_table', 1),
(32, '2022_04_22_091745_create_credits_table', 1);

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\Info\\User', 1),
(2, 'App\\Models\\Info\\User', 2);

CREATE TABLE `nova_froala_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `attachable_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachable_id` int(11) DEFAULT NULL,
  `attachment` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `nova_menu_menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `nova_menu_menu_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `menu_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `data` json DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `nova_pending_froala_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `draft_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `nova_pending_trix_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `draft_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `nova_trix_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `attachable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachable_id` int(10) UNSIGNED NOT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `group`) VALUES
(1, 'account.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'account'),
(2, 'account.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'account'),
(3, 'account.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'account'),
(4, 'account.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'account'),
(5, 'account.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'account'),
(6, 'account.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'account'),
(7, 'account.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'account'),
(8, 'client.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'client'),
(9, 'client.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'client'),
(10, 'client.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'client'),
(11, 'client.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'client'),
(12, 'client.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'client'),
(13, 'client.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'client'),
(14, 'client.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'client'),
(15, 'setting.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'setting'),
(16, 'setting.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'setting'),
(17, 'setting.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'setting'),
(18, 'setting.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'setting'),
(19, 'setting.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'setting'),
(20, 'setting.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'setting'),
(21, 'setting.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'setting'),
(22, 'entry_category.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'entry_category'),
(23, 'entry_category.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'entry_category'),
(24, 'entry_category.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'entry_category'),
(25, 'entry_category.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'entry_category'),
(26, 'entry_category.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'entry_category'),
(27, 'entry_category.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'entry_category'),
(28, 'entry_category.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'entry_category'),
(29, 'project.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project'),
(30, 'project.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project'),
(31, 'project.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project'),
(32, 'project.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project'),
(33, 'project.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project'),
(34, 'project.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project'),
(35, 'project.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project'),
(36, 'project_status.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project_status'),
(37, 'project_status.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project_status'),
(38, 'project_status.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project_status'),
(39, 'project_status.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project_status'),
(40, 'project_status.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project_status'),
(41, 'project_status.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project_status'),
(42, 'project_status.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'project_status'),
(43, 'expense.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'expense'),
(44, 'expense.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'expense'),
(45, 'expense.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'expense'),
(46, 'expense.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'expense'),
(47, 'expense.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'expense'),
(48, 'expense.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'expense'),
(49, 'expense.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'expense'),
(50, 'credit_category.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit_category'),
(51, 'credit_category.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit_category'),
(52, 'credit_category.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit_category'),
(53, 'credit_category.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit_category'),
(54, 'credit_category.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit_category'),
(55, 'credit_category.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit_category'),
(56, 'credit_category.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit_category'),
(57, 'credit.view_any', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit'),
(58, 'credit.view', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit'),
(59, 'credit.create', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit'),
(60, 'credit.edit', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit'),
(61, 'credit.delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit'),
(62, 'credit.restore', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit'),
(63, 'credit.force_delete', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19', 'credit');

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `project_status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `cost` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `projects` (`id`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`, `project_status_id`, `cost`) VALUES
(1, 'P1', 1, '2022-04-22 11:36:32', '2022-04-22 11:36:32', NULL, 1, 100000),
(2, 'P2', 1, '2022-04-22 11:37:16', '2022-04-22 11:37:16', NULL, 1, 500000),
(3, 'P3', 1, '2022-04-30 13:41:38', '2022-04-30 13:41:38', NULL, 1, 10);

CREATE TABLE `project_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `project_statuses` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'New', '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(2, 'Under Construction', '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(3, 'Finished', '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL),
(4, 'Canceled', '2022-04-22 11:35:19', '2022-04-22 11:35:19', NULL);

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'web', '2022-04-22 11:35:19', '2022-04-22 11:35:19'),
(2, 'user', 'web', '2022-04-30 17:59:03', '2022-04-30 17:59:03');

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(8, 2),
(9, 2),
(11, 2),
(12, 2),
(13, 2),
(14, 2),
(52, 2),
(53, 2),
(54, 2),
(57, 2),
(58, 2),
(59, 2),
(60, 2),
(61, 2),
(62, 2),
(63, 2);

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'title,description,keywords,icon,theme',
  `value` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `locale`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', 'admin@app.com', NULL, '$2y$10$WwohGhbIRl8QnrgyV2cVcOOEG0iHKVmNlprr6huO3CMb9keq8kZdK', 'ar', NULL, '2022-04-22 11:35:19', '2022-04-30 17:47:31', NULL),
(2, 'user', 'user@user.com', NULL, '$2y$10$m6E1SnZlM2txm.WcSc06qOCaPFcDya2/lsypjPCV64LtZ6Q7UCquC', 'ar', NULL, '2022-04-30 18:00:28', '2022-04-30 18:08:04', NULL);


ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `action_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `action_events_actionable_type_actionable_id_index` (`actionable_type`,`actionable_id`),
  ADD KEY `action_events_batch_id_model_type_model_id_index` (`batch_id`,`model_type`,`model_id`),
  ADD KEY `action_events_user_id_index` (`user_id`);

ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `credits`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `credit_categories`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `entry_categories`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

ALTER TABLE `language_lines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `language_lines_group_index` (`group`);

ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media_uuid_unique` (`uuid`),
  ADD KEY `media_model_type_model_id_index` (`model_type`,`model_id`);

ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

ALTER TABLE `nova_froala_attachments`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `nova_menu_menus`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `nova_menu_menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nova_menu_menu_items_menu_id_foreign` (`menu_id`);

ALTER TABLE `nova_pending_froala_attachments`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `nova_pending_trix_attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nova_pending_trix_attachments_draft_id_index` (`draft_id`);

ALTER TABLE `nova_trix_attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nova_trix_attachments_attachable_type_attachable_id_index` (`attachable_type`,`attachable_id`),
  ADD KEY `nova_trix_attachments_url_index` (`url`);

ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `project_statuses`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);


ALTER TABLE `accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `action_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `credits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `credit_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `entry_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `language_lines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

ALTER TABLE `nova_froala_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `nova_menu_menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `nova_menu_menu_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `nova_pending_froala_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `nova_pending_trix_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `nova_trix_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `project_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;


ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

ALTER TABLE `nova_menu_menu_items`
  ADD CONSTRAINT `nova_menu_menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `nova_menu_menus` (`id`) ON DELETE CASCADE;

ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
