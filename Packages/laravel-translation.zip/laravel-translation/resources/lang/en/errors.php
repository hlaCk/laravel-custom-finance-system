<?php

return [
    'language_exists' => 'The language { :language } already exists',
    'key_exists' => 'The translation key { :key } already exists',
];
